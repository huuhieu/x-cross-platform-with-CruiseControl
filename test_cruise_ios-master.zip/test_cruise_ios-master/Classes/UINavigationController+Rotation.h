//
//  UINavigationController+Rotation.h
//  WordPress
//
//  Created by Eric J on 9/19/12.
//  Copyright (c) 2012 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (Rotation)

@end

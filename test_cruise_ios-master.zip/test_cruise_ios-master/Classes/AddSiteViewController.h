//
//  AddSiteViewController.h
//  WordPress
//
//  Created by Chris Boyd on 7/23/10.
//

#import <UIKit/UIKit.h>
#import "EditSiteViewController.h"

@interface AddSiteViewController : EditSiteViewController {
}

@end

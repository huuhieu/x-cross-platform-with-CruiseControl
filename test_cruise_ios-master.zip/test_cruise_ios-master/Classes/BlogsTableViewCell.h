//
//  BlogsTableViewCell.h
//  WordPress
//
//  Created by Dan Roundhill on 3/24/11.
//  Copyright 2011 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlogsTableViewCell : UITableViewCell {
    
}

@end

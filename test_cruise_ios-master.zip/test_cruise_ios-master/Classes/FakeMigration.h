//
//  FakeMigration.h
//  WordPress
//
//  Created by Jorge Bernal on 2/21/11.
//  Copyright 2011 WordPress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FakeMigration : NSEntityMigrationPolicy {

}

@end

//
//  PostToAbstractPost.h
//  WordPress
//
//  Created by Jorge Bernal on 2/16/11.
//  Copyright 2011 WordPress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PostToAbstractPost : NSEntityMigrationPolicy {

}

@end

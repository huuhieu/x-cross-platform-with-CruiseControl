//
//  UINavigationBar+Styled.h
//  WordPress
//
//  Created by Eric Johnson on 7/6/12.
//  Copyright (c) 2012 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (Styled) 

@end

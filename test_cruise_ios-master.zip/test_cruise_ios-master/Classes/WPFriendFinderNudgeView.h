//
//  WPFriendFinderNudgeView.h
//  WordPress
//
//  Created by Beau Collins on 7/3/12.
//  Copyright (c) 2012 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WPFriendFinderNudgeView : UIView

@property (nonatomic, strong) UIButton *cancelButton;
@property (nonatomic, strong) UIButton *confirmButton;

@end

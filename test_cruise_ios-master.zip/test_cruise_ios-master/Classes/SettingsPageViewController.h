//
//  SettingsPageViewController.h
//  WordPress
//
//  Created by Eric Johnson on 9/3/12.
//  Copyright (c) 2012 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsPageViewController : UITableViewController

- (id)initWithDictionary:(NSDictionary *)dictionary;

@end

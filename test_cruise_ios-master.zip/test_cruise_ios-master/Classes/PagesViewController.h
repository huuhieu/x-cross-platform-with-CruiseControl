//
//  PagesViewController.h
//  WordPress
//
//  Created by Janakiram on 01/11/08.
//

#import <Foundation/Foundation.h>
#import "PostsViewController.h"
#import "Page.h"

@interface PagesViewController : PostsViewController {
}
@end

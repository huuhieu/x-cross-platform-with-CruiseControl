//
//  UIViewController+Rotation.h
//  WordPress
//
//  Created by Danilo Ercoli on 13/07/12.
//  Copyright (c) 2012 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface UIViewController (Rotation)

@end

//
//  EditPageViewController.h
//  WordPress
//
//  Created by Chris Boyd on 9/4/10.
//

#import <UIKit/UIKit.h>
#import "EditPostViewController.h"

@interface EditPageViewController : EditPostViewController {
}

@end

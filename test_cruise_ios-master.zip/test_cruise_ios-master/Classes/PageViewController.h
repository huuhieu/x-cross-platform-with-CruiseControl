//
//  PageViewController.h
//  WordPress
//
//  Created by Jorge Bernal on 1/17/11.
//  Copyright 2011 WordPress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PostViewController.h"

@interface PageViewController : PostViewController {

}
@end

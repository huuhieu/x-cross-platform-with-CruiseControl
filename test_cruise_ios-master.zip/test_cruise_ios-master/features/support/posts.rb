POSTS = {
    :karl => [{
                   :title => "Hello X-Platform",
                   :date => "May 7, 2013"
               }],

    :new => {
        :title => "New post",
        :body => "This is a new post"
    }
}
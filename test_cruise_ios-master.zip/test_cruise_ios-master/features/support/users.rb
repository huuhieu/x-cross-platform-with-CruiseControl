USERS = {
    :karl => {
        :email => "karl@lesspainful.com",
        :password => "Calabash321"
    },
    :invalid => {
        :email => "jonas2@lesspainful.com",
        :password => "1234567892"
    }
}
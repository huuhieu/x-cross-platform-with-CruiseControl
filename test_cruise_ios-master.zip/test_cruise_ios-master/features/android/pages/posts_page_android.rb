require 'calabash-android/abase'

class PostsPage < Calabash::ABase



end
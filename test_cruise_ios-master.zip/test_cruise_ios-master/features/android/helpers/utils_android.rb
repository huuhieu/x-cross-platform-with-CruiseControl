def logged_in?
end

def wait_for_animation
  sleep(0.6)
end
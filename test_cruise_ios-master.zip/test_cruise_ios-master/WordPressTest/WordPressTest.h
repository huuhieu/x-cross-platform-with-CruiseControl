//
//  WordPressTest.h
//  WordPressTest
//
//  Created by Jorge Bernal on 2/1/12.
//  Copyright (c) 2012 Automattic. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface WordPressTest : SenTestCase

@end
